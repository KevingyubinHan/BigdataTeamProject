"""
두 개의 입력값을 더한 값을 출력하는 함수 add(x, y)를 작성
"""


def test_add():
    x = 1
    y = 2
    assert 3 == add(x, y)


def test_add_2():
    x = 3
    y = 4
    assert 7 == add(x, y)


def add(x, y):
    return x + y
