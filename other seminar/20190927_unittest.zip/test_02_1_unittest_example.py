import unittest


class TestAdd(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    # NOTE: 모든 테스트 메소드는 "test"로 시작해야 함
    def test_add(self):
        x = 1
        y = 2
        self.assertEqual(3, add(x, y))  # NOTE: assertion 관련 다양한 함수를 사용할 수 있음

    def test_add_2(self):
        x = 3
        y = 4
        self.assertEqual(7, add(x, y))


def add(x, y):
    return x + y
