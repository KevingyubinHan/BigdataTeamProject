import pytest


@pytest.fixture
def tom():
    toms_asset = {'apple': 2,
                  'orange': 4}
    return toms_asset


@pytest.fixture
def jerry():
    jerrys_asset = {'apple': 5,
                    'orange': 0}
    return jerrys_asset


def give_apples(giver, taker, num_apples):
    if giver['apple'] < num_apples:
        print("Not enough apples!")
        return

    giver['apple'] -= num_apples
    taker['apple'] += num_apples
    return


def test_giving_apples(tom, jerry):
    # Given
    assert tom['apple'] == 2
    assert jerry['apple'] == 5

    # When
    give_apples(tom, jerry, 2)

    # Then
    assert tom['apple'] == 0
    assert jerry['apple'] == 7
