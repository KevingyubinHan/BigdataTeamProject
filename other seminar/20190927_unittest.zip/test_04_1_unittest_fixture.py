import unittest


class FixtureTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # print("\nsetUpClass")
        pass

    def setUp(self):
        # print("\nsetUp")
        self.x = 3

    def tearDown(self):
        # print("\ntearDown")
        pass

    @classmethod
    def tearDownClass(cls):
        # print("\ntearDownClass")
        pass

    def test_adding_once(self):
        # print("\ntest_adding_once")
        self.x = add_one(self.x)
        self.assertEqual(4, self.x)

    def test_adding_twice(self):
        # print("\ntest_adding_twice")
        self.x = add_one(self.x)
        self.x = add_one(self.x)
        self.assertEqual(5, self.x)


def add_one(x):
    return x + 1
