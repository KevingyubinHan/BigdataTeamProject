import pytest


@pytest.fixture()
def x():
    x = 3
    return x


def test_adding_once(x):
    x = add_one(x)
    assert 4 == x


def test_adding_twice(x):
    x = add_one(x)
    x = add_one(x)
    assert 5 == x


def add_one(x):
    return x + 1
