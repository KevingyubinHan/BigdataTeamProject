import os
from unittest import mock


def rm(filepath):
    try:
        os.remove(filepath)
    except OSError:
        print(f"ERROR - no such a file: {filepath}")
        return False
    return True


def test_rm():
    print(f"\n[os.remove in test_rm] {os.remove}")
    target_filepath = "/abc.txt"
    result = rm(target_filepath)
    assert not result


@mock.patch('os.remove')
def test_rm_with_mock(os_remove):
    print(f"\n[os.remove in test_rm_with_mock] {os.remove}")
    target_filepath = "/def.txt"
    result = rm(target_filepath)
    os_remove.assert_called_with("/def.txt")
    assert result
